# Package marker for Aurion plugin libraries.
